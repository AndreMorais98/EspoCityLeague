import React from 'react';

export default function Rules() {
  return (
    <div>
      <h2>Rules</h2>
      <ul>
        <li>Correct outcome: points TBD</li>
        <li>Exact score: points TBD</li>
        <li>One bet per user per match</li>
      </ul>
    </div>
  );
}
