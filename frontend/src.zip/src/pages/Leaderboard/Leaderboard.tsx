import React, { useEffect, useState } from 'react';

interface User {
  id: number;
  username: string;
  phone: string;
  score: number;
  is_active: boolean;
  is_superuser: boolean;
}

export default function Leaderboard() {

  return (
    <div>
      <h2>Leaderboard</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '20px' }}>
        <thead>
          <tr style={{ backgroundColor: '#374151' }}>
            <th style={{ padding: '12px', textAlign: 'left', borderBottom: '1px solid #4B5563' }}>Rank</th>
            <th style={{ padding: '12px', textAlign: 'left', borderBottom: '1px solid #4B5563' }}>Username</th>
            <th style={{ padding: '12px', textAlign: 'left', borderBottom: '1px solid #4B5563' }}>Score</th>
          </tr>
        </thead>
      </table>
    </div>
  );
}
