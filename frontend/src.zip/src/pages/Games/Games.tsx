import React from 'react';

export default function Games() {
  return (
    <div>
      <h2>Games</h2>
      <p>Coming soon: list of matches to bet on.</p>
    </div>
  );
}
